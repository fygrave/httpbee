print( "Testing the C++ LUA Wrapper" );


print( getenv( "HOME" ) );

system( "/usr/bin/id" );

print ( "Launched process .." );

os.execute( "id > t");


--
--  Called from C++
--
function test( string )
	print ("String is : " .. string );
	return 32;
end